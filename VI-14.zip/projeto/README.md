To run:
	1) in the folder of index.html open the bash
	2) with python3:  	python -m http.server 8888
		with python: 	python -m SimpleHTTPServer 8888
	3) open the link: http://localhost:8888/index.html

Project done and tested in Google Chrome

Infovis done with d3.js v5.
To the slide ranger we use a file d3-simple-slider. That is in d3 folder.

A video with better resoltion can be fouded here:
	Youtube: https://www.youtube.com/watch?v=g4q9bvwzxrI
